class Friend < ApplicationRecord
end
